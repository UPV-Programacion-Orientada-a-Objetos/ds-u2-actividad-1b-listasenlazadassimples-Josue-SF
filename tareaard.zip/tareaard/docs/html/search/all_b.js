var searchData=
[
  ['sensorbase_0',['SensorBase',['../classSensorBase.html',1,'']]],
  ['sensorbase_2eh_1',['SensorBase.h',['../SensorBase_8h.html',1,'']]],
  ['sensorpres_2eh_2',['SensorPres.h',['../SensorPres_8h.html',1,'']]],
  ['sensorpresion_3',['sensorpresion',['../classSensorPresion.html',1,'SensorPresion'],['../classSensorPresion.html#a9febd6b22421efe40ba531d5137bedfd',1,'SensorPresion::SensorPresion()']]],
  ['sensortemp_2eh_4',['SensorTemp.h',['../SensorTemp_8h.html',1,'']]],
  ['sensortemperatura_5',['sensortemperatura',['../classSensorTemperatura.html',1,'SensorTemperatura'],['../classSensorTemperatura.html#a13063a6569078d34573d3a3af703e34f',1,'SensorTemperatura::SensorTemperatura()']]],
  ['serialmgr_6',['serialmgr',['../classSerialMgr.html',1,'SerialMgr'],['../classSerialMgr.html#ab57a0a1e86550df93f31dd420496b133',1,'SerialMgr::SerialMgr()']]],
  ['serialmgr_2eh_7',['SerialMgr.h',['../SerialMgr_8h.html',1,'']]],
  ['sig_8',['sig',['../structNodoG.html#aa13c498ffc4879e200cb68fbf5445f18',1,'NodoG::sig'],['../structNodo.html#a91ef988790cba2200452f28cf0446712',1,'Nodo::sig']]],
  ['sns_9',['sns',['../structNodoG.html#aecffb800b4e4e3dbc88cca01e67b1aa1',1,'NodoG']]]
];
