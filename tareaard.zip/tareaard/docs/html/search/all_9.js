var searchData=
[
  ['procesarlectura_0',['procesarLectura',['../classSerialMgr.html#aabcc7f7cae4a65ec7745d632f43f5f50',1,'SerialMgr']]],
  ['proclect_1',['proclect',['../classSensorBase.html#af4ce1fb80086f39ead6095537e7a5b0a',1,'SensorBase::procLect()'],['../classSensorPresion.html#aefd66649d470bb919e3fea58a49602d7',1,'SensorPresion::procLect()'],['../classSensorTemperatura.html#a81f51adbf4f029c88ba75adde5cf91f9',1,'SensorTemperatura::procLect()']]],
  ['proctodo_2',['procTodo',['../classListaGest.html#a1034b891b5ac068cb03ccd75a26fbe1e',1,'ListaGest']]]
];
