var searchData=
[
  ['leerserial_0',['leerSerial',['../classSerialMgr.html#a50f4aef1d9137c5d2a21e182152b74bb',1,'SerialMgr']]],
  ['listagest_1',['ListaGest',['../classListaGest.html#a911d70118fe7ed9c72b93f23e5a5e3f7',1,'ListaGest']]],
  ['listasensor_2',['listasensor',['../classListaSensor.html#add555365175bf2140b81b9a2b5a303f5',1,'ListaSensor::ListaSensor()'],['../classListaSensor.html#ad4256b8b20a04964a2eec0dce5526bcf',1,'ListaSensor::ListaSensor(const ListaSensor &amp;otr)=delete']]]
];
