var searchData=
[
  ['impr_0',['impr',['../classListaSensor.html#a0ea9457aad849361d664b1eacd8dd273',1,'ListaSensor']]],
  ['imprinf_1',['imprinf',['../classSensorBase.html#a6dbe73f94088168048bc47ab9b4dbf33',1,'SensorBase::imprInf()'],['../classSensorPresion.html#a195a6460b639d359e75320441fe8452d',1,'SensorPresion::imprInf()'],['../classSensorTemperatura.html#a62e3dd1dcc179b64314c3cca126863f2',1,'SensorTemperatura::imprInf()']]],
  ['insfin_2',['insfin',['../classListaGest.html#a21578be493df03e1c98065c1c8b22e46',1,'ListaGest::insFin()'],['../classListaSensor.html#a4f39767d9bb7d2b6de9da332ddc05a41',1,'ListaSensor::insFin()']]]
];
