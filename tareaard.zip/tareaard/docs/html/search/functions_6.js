var searchData=
[
  ['nodo_0',['Nodo',['../structNodo.html#ae96eebd81fdcc626a95c8f4357a1c5b3',1,'Nodo']]],
  ['nodog_1',['NodoG',['../structNodoG.html#a5498ea50f4ce0454091a265b524ed54e',1,'NodoG']]]
];
