var searchData=
[
  ['estalisto_0',['estaListo',['../classSerialMgr.html#a0e6ed6e4314e2a0ff5c06e4a01d79c79',1,'SerialMgr']]]
];
