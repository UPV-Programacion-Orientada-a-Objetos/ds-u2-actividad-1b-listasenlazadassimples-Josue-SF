var searchData=
[
  ['reglect_0',['reglect',['../classSensorBase.html#abed043f299f4ff387e1d9923b08faba9',1,'SensorBase::regLect(float val)'],['../classSensorBase.html#af83f26e1d7d5d4c4ad5f1bdaff31d38f',1,'SensorBase::regLect(int val)'],['../classSensorPresion.html#a012c20ab1659664dda2cdb923fe0c375',1,'SensorPresion::regLect()'],['../classSensorTemperatura.html#a4b3b0eed5456d5e06f516d8cf9ef1973',1,'SensorTemperatura::regLect()']]]
];
