var searchData=
[
  ['leerserial_0',['leerSerial',['../classSerialMgr.html#a50f4aef1d9137c5d2a21e182152b74bb',1,'SerialMgr']]],
  ['listagest_1',['listagest',['../classListaGest.html',1,'ListaGest'],['../classListaGest.html#a911d70118fe7ed9c72b93f23e5a5e3f7',1,'ListaGest::ListaGest()']]],
  ['listagest_2eh_2',['ListaGest.h',['../ListaGest_8h.html',1,'']]],
  ['listasensor_3',['listasensor',['../classListaSensor.html',1,'ListaSensor&lt; T &gt;'],['../classListaSensor.html#add555365175bf2140b81b9a2b5a303f5',1,'ListaSensor::ListaSensor()'],['../classListaSensor.html#ad4256b8b20a04964a2eec0dce5526bcf',1,'ListaSensor::ListaSensor(const ListaSensor &amp;otr)=delete']]],
  ['listasensor_2eh_4',['ListaSensor.h',['../ListaSensor_8h.html',1,'']]],
  ['listasensor_3c_20float_20_3e_5',['ListaSensor&lt; float &gt;',['../classListaSensor.html',1,'']]],
  ['listasensor_3c_20int_20_3e_6',['ListaSensor&lt; int &gt;',['../classListaSensor.html',1,'']]]
];
