var searchData=
[
  ['dat_0',['dat',['../structNodo.html#aef84725d2393bb2db5ccba37fce538dc',1,'Nodo']]]
];
