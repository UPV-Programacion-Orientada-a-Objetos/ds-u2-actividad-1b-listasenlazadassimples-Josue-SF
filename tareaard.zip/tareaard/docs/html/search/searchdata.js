var indexSectionsWithContent =
{
  0: "bcdeilmnoprs~",
  1: "lns",
  2: "lms",
  3: "bceilmnoprs~",
  4: "dns"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

