var searchData=
[
  ['sensorpresion_0',['SensorPresion',['../classSensorPresion.html#a9febd6b22421efe40ba531d5137bedfd',1,'SensorPresion']]],
  ['sensortemperatura_1',['SensorTemperatura',['../classSensorTemperatura.html#a13063a6569078d34573d3a3af703e34f',1,'SensorTemperatura']]],
  ['serialmgr_2',['SerialMgr',['../classSerialMgr.html#ab57a0a1e86550df93f31dd420496b133',1,'SerialMgr']]]
];
