var searchData=
[
  ['sig_0',['sig',['../structNodoG.html#aa13c498ffc4879e200cb68fbf5445f18',1,'NodoG::sig'],['../structNodo.html#a91ef988790cba2200452f28cf0446712',1,'Nodo::sig']]],
  ['sns_1',['sns',['../structNodoG.html#aecffb800b4e4e3dbc88cca01e67b1aa1',1,'NodoG']]]
];
