var searchData=
[
  ['busnom_0',['busNom',['../classListaGest.html#ab308600810565843e7e3e3d0c88d89d8',1,'ListaGest']]]
];
