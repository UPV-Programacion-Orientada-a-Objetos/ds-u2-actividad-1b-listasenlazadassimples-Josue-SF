/**
 * @file ListaSensor.h
 * @brief [BREVE] Documentación añadida automáticamente (Doxygen/JSDoc compatible).
 */

#ifndef LST_SNS_H
#define LST_SNS_H

#include <iostream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>

template <typename T>
struct Nodo {
    T dat; 
    Nodo<T>* sig; 

    Nodo(T d) : dat(d), sig(nullptr) {}
};

template <typename T>
class ListaSensor {
private:
    Nodo<T>* cab; 
/**
 * @brief [BREVE] libMem — descripción.
 */

    void libMem() {
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return Nodo<T>* act = cab; [descripcion]
 */
        Nodo<T>* act = cab;
        while (act != nullptr) {
            Nodo<T>* prox = act->sig;
            std::cout << "    [Log] Nodo<" << typeid(T).name() << "> " << act->dat << " liberado." << std::endl;
            delete act;
            act = prox;
        }
        cab = nullptr;
    }

public:
    ListaSensor() : cab(nullptr) {}

    ~ListaSensor() {
/**
 * @brief [BREVE] libMem — descripción.
 */
        libMem();
    }

    ListaSensor(const ListaSensor& otr) = delete;
    ListaSensor& operator=(const ListaSensor& otr) = delete;
/**
 * @brief [BREVE] insFin — descripción.
 * @param dat [descripcion]
 */

    void insFin(T dat) {
        Nodo<T>* nvo = new Nodo<T>(dat);
/**
 * @brief [BREVE] if — descripción.
 * @param cab [descripcion]
 */
        if (cab == nullptr) {
            cab = nvo;
        } else {
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return Nodo<T>* act = cab; [descripcion]
 */
            Nodo<T>* act = cab;
            while (act->sig != nullptr) {
                act = act->sig;
            }
            act->sig = nvo;
        }
    }
/**
 * @brief [BREVE] obtYEliMin — descripción.
 * @return T [descripcion]
 */

    T obtYEliMin() {
        if (cab == nullptr) throw std::out_of_range("Lst vac.");

        Nodo<T>* act = cab;
        Nodo<T>* minN = cab;
        Nodo<T>* antMinN = nullptr;
/**
 * @brief [BREVE] if — descripción.
 * @param nullptr [descripcion]
 * @return T minV = cab->dat; [descripcion]
 */
        T minV = cab->dat;
        
        if (cab->sig != nullptr) {
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return Nodo<T>* temp = cab; [descripcion]
 */
            Nodo<T>* temp = cab;
            while (temp->sig != nullptr) {
/**
 * @brief [BREVE] if — descripción.
 * @param minV [descripcion]
 */
                if (temp->sig->dat < minV) {
                    minV = temp->sig->dat;
                    minN = temp->sig;
                    antMinN = temp;
                }
                temp = temp->sig;
            }
/**
 * @brief [BREVE] if — descripción.
 * @param minN [descripcion]
 * @return } [descripcion]
 */
        }

        if (minN == cab) {
            cab = cab->sig; 
        } else {
            antMinN->sig = minN->sig;
        }
        
        T res = minN->dat;
        std::cout << "  [Log] Eliminando val: " << res << std::endl;
        delete minN;
        return res;
    }
/**
 * @brief [BREVE] calcProm — descripción.
 * @return float [descripcion]
 */

    float calcProm() const {
        if (cab == nullptr) return 0.0f;
/**
 * @brief [BREVE] T — descripción.
 */

        T sum = T(); 
        int cnt = 0; 
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return Nodo<T>* act = cab; [descripcion]
 */
        Nodo<T>* act = cab;

        while (act != nullptr) {
            sum = sum + act->dat;
            cnt++;
            act = act->sig;
        }
        
        return static_cast<float>(sum) / cnt;
    }
/**
 * @brief [BREVE] obtCnt — descripción.
 * @return int [descripcion]
 */
    
    int obtCnt() const {
        int cnt = 0;
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return Nodo<T>* act = cab; [descripcion]
 */
        Nodo<T>* act = cab;
        while (act != nullptr) {
            cnt++;
            act = act->sig;
        }
        return cnt;
    }
/**
 * @brief [BREVE] impr — descripción.
 */
    
    void impr() const {
        Nodo<T>* act = cab;
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return std::cout << "["; [descripcion]
 */
        std::cout << "[";
        while (act != nullptr) {
/**
 * @brief [BREVE] if — descripción.
 * @param nullptr [descripcion]
 * @return std::cout << act->dat; [descripcion]
 */
            std::cout << act->dat;
            if (act->sig != nullptr) {
                std::cout << ", ";
            }
            act = act->sig;
        }
        std::cout << "]";
    }
};

#endif // LST_SNS_H
