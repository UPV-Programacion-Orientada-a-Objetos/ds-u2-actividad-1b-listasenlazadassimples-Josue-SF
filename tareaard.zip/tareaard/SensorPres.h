/**
 * @file SensorPres.h
 * @brief [BREVE] Documentación añadida automáticamente (Doxygen/JSDoc compatible).
 */

#ifndef SENS_PRS_H
#define SENS_PRS_H

#include "SensorBase.h"
#include "ListaSensor.h"

class SensorPresion : public SensorBase {
private:
    ListaSensor<int> hist; 
/**
 * @brief [BREVE] SensorPresion — descripción.
 * @param id [descripcion]
 * @return public: [descripcion]
 */

public:
    SensorPresion(const char* id) {
/**
 * @brief [BREVE] strncpy — descripción.
 * @param nom [descripcion]
 * @param id [descripcion]
 * @param param [descripcion]
 */
        strncpy(nom, id, 49);
        nom[49] = '\0';
    }

    ~SensorPresion() override {
        std::cout << "  [Dtor Sens Pres] Lib Lst Int..." << std::endl;
    }

    void regLect(int val) override {
        hist.insFin(val);
    }

    void procLect() override {
        if (hist.obtCnt() == 0) {
            std::cout << "[" << nom << "] (Pres): No hay lecturas." << std::endl;
            return;
        }

        float prom = hist.calcProm();
        
        std::cout << "[" << nom << "] (Pres): Promedio lect: " << prom << ".";
/**
 * @brief [BREVE] imprInf — descripción.
 */
        imprInf();
    }

    void imprInf() const override {
        std::cout << "  [Inf " << nom << "]: Lecturas (" << hist.obtCnt() << "): ";
        hist.impr();
        std::cout << std::endl;
    }
};

#endif // SENS_PRS_H
