/**
 * @file SensorBase.h
 * @brief [BREVE] Documentación añadida automáticamente (Doxygen/JSDoc compatible).
 */

#ifndef SENS_B_H
#define SENS_B_H

#include <iostream>
#include <cstring>

class SensorBase {
protected:
    char nom[50]; 

public:
    virtual ~SensorBase() {
        std::cout << "  [Dtor SensorBase] Lib ID: " << nom << std::endl;
    }

    virtual void procLect() = 0; 
    virtual void imprInf() const = 0; 
/**
 * @brief [BREVE] obtNom — descripción.
 * @return const char* [descripcion]
 */

    const char* obtNom() const { return nom; }
/**
 * @brief [BREVE] regLect — descripción.
 * @param val [descripcion]
 * @return virtual void [descripcion]
 */

    virtual void regLect(float val) {}
/**
 * @brief [BREVE] regLect — descripción.
 * @param val [descripcion]
 * @return virtual void [descripcion]
 */
    virtual void regLect(int val) {}
};

#endif // SENS_B_H
