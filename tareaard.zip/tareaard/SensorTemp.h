/**
 * @file SensorTemp.h
 * @brief [BREVE] Documentación añadida automáticamente (Doxygen/JSDoc compatible).
 */

#ifndef SENS_TMP_H
#define SENS_TMP_H

#include "SensorBase.h"
#include "ListaSensor.h"

class SensorTemperatura : public SensorBase {
private:
    ListaSensor<float> hist; 
/**
 * @brief [BREVE] SensorTemperatura — descripción.
 * @param id [descripcion]
 * @return public: [descripcion]
 */

public:
    SensorTemperatura(const char* id) {
/**
 * @brief [BREVE] strncpy — descripción.
 * @param nom [descripcion]
 * @param id [descripcion]
 * @param param [descripcion]
 */
        strncpy(nom, id, 49);
        nom[49] = '\0';
    }

    ~SensorTemperatura() override {
        std::cout << "  [Dtor Sens Temp] Lib Lst Int..." << std::endl;
    }

    void regLect(float val) override {
        hist.insFin(val);
    }

    void procLect() override {
        if (hist.obtCnt() == 0) {
            std::cout << "[" << nom << "] (Temp): No hay lecturas." << std::endl;
            return;
        }
        
        float minV = hist.obtYEliMin(); 
        float promR = hist.calcProm(); 

        std::cout << "[" << nom << "] (Temp): Lectura min (" << minV << ") elim. Promedio res: " << promR << "." << std::endl;
/**
 * @brief [BREVE] imprInf — descripción.
 */
        imprInf();
    }

    void imprInf() const override {
        std::cout << "  [Inf " << nom << "]: Lecturas res (" << hist.obtCnt() << "): ";
        hist.impr();
        std::cout << std::endl;
    }
};

#endif // SENS_TMP_H
