/**
 * @file SerialMgr.h
 * @brief [BREVE] Documentación añadida automáticamente (Doxygen/JSDoc compatible).
 */

#ifndef SERIAL_MGR_H
#define SERIAL_MGR_H

#include "SensorBase.h"
#include "ListaGest.h" 
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h> 
#include <fcntl.h>   
#include <termios.h> 
#include <cerrno>

class SerialMgr {
private:
    int fd; 
    const char* pto;
/**
 * @brief [BREVE] configPort — descripción.
 * @return bool [descripcion]
 */

    bool configPort() {
/**
 * @brief [BREVE] Clase/estructura termios.
 */
        struct termios tty;
        
        if (tcgetattr(fd, &tty) != 0) {
            std::cerr << "[S Err] F config: " << strerror(errno) << std::endl;
            return false;
        }

        tty.c_cflag &= ~PARENB;     
        tty.c_cflag &= ~CSTOPB;     
        tty.c_cflag &= ~CSIZE;
        tty.c_cflag |= CS8;         
        tty.c_cflag &= ~CRTSCTS;    
        tty.c_cflag |= CREAD | CLOCAL;

        tty.c_lflag &= ~ICANON;     
        tty.c_lflag &= ~ECHO;       
        tty.c_lflag &= ~ECHOE;      
        tty.c_lflag &= ~ECHONL;     
        tty.c_lflag &= ~ISIG;       

        tty.c_iflag &= ~(IXON | IXOFF | IXANY);
        tty.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP|INLCR|IGNCR|ICRNL);

        tty.c_oflag &= ~OPOST;      
/**
 * @brief [BREVE] cfsetispeed — descripción.
 * @param tty [descripcion]
 * @param B9600 [descripcion]
 */
        tty.c_oflag &= ~ONLCR;      

        cfsetispeed(&tty, B9600); 
/**
 * @brief [BREVE] cfsetospeed — descripción.
 * @param tty [descripcion]
 * @param B9600 [descripcion]
 */
        cfsetospeed(&tty, B9600); 

        tty.c_cc[VTIME] = 5; 
        tty.c_cc[VMIN] = 0; 

        if (tcsetattr(fd, TCSANOW, &tty) != 0) {
            std::cerr << "[S Err] F set: " << strerror(errno) << std::endl;
            return false;
        }
        return true;
    }

public:
    SerialMgr(const char* p) : pto(p), fd(-1) {
/**
 * @brief [BREVE] open — descripción.
 * @param p [descripcion]
 * @param O_NOCTTY [descripcion]
 */
        fd = open(p, O_RDWR | O_NOCTTY);
/**
 * @brief [BREVE] if — descripción.
 * @param param [descripcion]
 */
        
        if (fd < 0) {
            std::cerr << "[S Err] F abrir " << pto << ": " << strerror(errno) << std::endl;
            return;
        }

        if (!configPort()) {
/**
 * @brief [BREVE] close — descripción.
 * @param fd [descripcion]
 */
            close(fd);
            fd = -1;
        } else {
            std::cout << "[S OK] Pto " << pto << " 9600 baudios." << std::endl;
        }
    }

    ~SerialMgr() {
/**
 * @brief [BREVE] if — descripción.
 * @param param [descripcion]
 */
        if (fd >= 0) {
/**
 * @brief [BREVE] close — descripción.
 * @param fd [descripcion]
 */
            close(fd);
            std::cout << "[S] Pto " << pto << " cerrado." << std::endl;
        }
    }
/**
 * @brief [BREVE] estaListo — descripción.
 * @return bool [descripcion]
 */
    
    bool estaListo() const { return fd >= 0; }
/**
 * @brief [BREVE] leerSerial — descripción.
 * @return char* [descripcion]
 */

    char* leerSerial() {
        if (fd < 0) return nullptr;

        static char buf[100]; 
        int idx = 0;
        char c;
        ssize_t n;

        while ((n = read(fd, &c, 1)) > 0) {
/**
 * @brief [BREVE] if — descripción.
 * @param c [descripcion]
 */
            if (c == '\n' || c == '\r' || idx >= 99) {
                break; 
            }
            buf[idx++] = c;
/**
 * @brief [BREVE] if — descripción.
 * @param param [descripcion]
 * @return } [descripcion]
 */
        }

        if (idx > 0) {
            buf[idx] = '\0'; 
/**
 * @brief [BREVE] strcpy — descripción.
 * @param res [descripcion]
 * @param buf [descripcion]
 */
            char* res = new char[idx + 1];
            strcpy(res, buf);
            std::cout << "\n[S] Leyendo: " << res << std::endl;
            return res;
        }
        
        return nullptr;
    }
/**
 * @brief [BREVE] procesarLectura — descripción.
 * @param lst [descripcion]
 * @param linea [descripcion]
 * @return bool [descripcion]
 */

    bool procesarLectura(ListaGest& lst, char* linea) {
/**
 * @brief [BREVE] strdup — descripción.
 * @param linea [descripcion]
 */
        char* l_cop = strdup(linea); 
/**
 * @brief [BREVE] strtok — descripción.
 * @param l_cop [descripcion]
 * @param param [descripcion]
 */
        
        char* id_s = strtok(l_cop, ":");
/**
 * @brief [BREVE] strtok — descripción.
 * @param nullptr [descripcion]
 * @param param [descripcion]
 */
        char* val_s = strtok(nullptr, ":");
/**
 * @brief [BREVE] if — descripción.
 * @param val_s [descripcion]
 */

        if (!id_s || !val_s) {
/**
 * @brief [BREVE] free — descripción.
 * @param l_cop [descripcion]
 */
            std::cerr << "[Err] Formato L S inc." << std::endl;
            free(l_cop);
            return false;
        }

        SensorBase* sns = lst.busNom(id_s);
/**
 * @brief [BREVE] if — descripción.
 * @param sns [descripcion]
 */
        if (!sns) {
/**
 * @brief [BREVE] free — descripción.
 * @param l_cop [descripcion]
 */
            std::cerr << "[Err] Sens '" << id_s << "' no enc." << std::endl;
            free(l_cop);
            return false;
/**
 * @brief [BREVE] if — descripción.
 * @param param [descripcion]
 * @return } [descripcion]
 */
        }
        
        if (id_s[0] == 'T') { 
/**
 * @brief [BREVE] std::atof — descripción.
 * @param val_s [descripcion]
 */
            float val = std::atof(val_s);
            sns->regLect(val); 
            std::cout << "[Log] -> Reg FLOAT en " << id_s << ": " << val << std::endl;
/**
 * @brief [BREVE] if — descripción.
 * @param param [descripcion]
 * @return } else [descripcion]
 */
        } else if (id_s[0] == 'P') {
/**
 * @brief [BREVE] std::atoi — descripción.
 * @param val_s [descripcion]
 */
            int val = std::atoi(val_s);
            sns->regLect(val); 
            std::cout << "[Log] -> Reg INT en " << id_s << ": " << val << std::endl;
/**
 * @brief [BREVE] free — descripción.
 * @param l_cop [descripcion]
 */
        }
        
        free(l_cop);
        return true;
    }
};

#endif // SERIAL_MGR_H
