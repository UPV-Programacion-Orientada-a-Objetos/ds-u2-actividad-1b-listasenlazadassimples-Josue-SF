/**
 * @file main.cpp
 * @brief [BREVE] Documentación añadida automáticamente (Doxygen/JSDoc compatible).
 */

#include "SensorBase.h"
#include "SensorTemp.h"
#include "SensorPres.h"
#include "ListaGest.h" 
#include "SerialMgr.h"
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h> 
/**
 * @brief [BREVE] main — descripción.
 * @return int [descripcion]
 */

int main() {
    
    ListaGest lstG; 
    
    // RUTA SERIAL: USADA AL ARDUINO (e.g., /dev/ttyUSB0 o /dev/ttyACM0)
/**
 * @brief [BREVE] sMgr — descripción.
 * @param param [descripcion]
 */
    SerialMgr sMgr("/dev/ttyUSB0"); 

    if (!sMgr.estaListo()) {
        std::cerr << "Saliendo... F abrir pto serial." << std::endl;
        return 1;
    }

    std::cout << "--- Sistema IoT Monit Polimorfico (Real) ---" << std::endl;
/**
 * @brief [BREVE] SensorTemperatura — descripción.
 * @param param [descripcion]
 */

    SensorBase* snsT = new SensorTemperatura("T-001");
    lstG.insFin(snsT);
/**
 * @brief [BREVE] SensorPresion — descripción.
 * @param param [descripcion]
 */
    
    SensorBase* snsP = new SensorPresion("P-105");
    lstG.insFin(snsP);
    
    std::cout << "\n[Sist] Listo. En espera de datos seriales. (Max 10 ciclos de lectura)" << std::endl;

    int maxCiclos = 10;
    int ciclos = 0;
/**
 * @brief [BREVE] while — descripción.
 * @param maxCiclos [descripcion]
 * @return // Bucle Principal de Lectura [descripcion]
 */
    
    // Bucle Principal de Lectura
    while (ciclos < maxCiclos) { 
/**
 * @brief [BREVE] usleep — descripción.
 * @param param [descripcion]
 */
        usleep(500000); 

        char* data = sMgr.leerSerial(); 
/**
 * @brief [BREVE] if — descripción.
 * @param nullptr [descripcion]
 */
        
        if (data != nullptr) {
            sMgr.procesarLectura(lstG, data);
            delete[] data; 
            ciclos++;
        }
    }
    
    std::cout << "\n[Sist] Max ciclos alcanzado. Procesando y finalizando." << std::endl;

    // Procesamiento Polimórfico
    lstG.procTodo();

    // Cierre
    std::cout << "\nOp 5: Cerrar Sist (Lib Mem)" << std::endl;

    return 0;
}
