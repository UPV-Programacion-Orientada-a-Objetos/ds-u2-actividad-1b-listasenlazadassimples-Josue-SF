/**
 * @file ListaGest.h
 * @brief [BREVE] Documentación añadida automáticamente (Doxygen/JSDoc compatible).
 */

#ifndef LST_GST_H
#define LST_GST_H

#include "SensorBase.h"
#include <iostream>
#include <cstring>

struct NodoG {
    SensorBase* sns; 
    NodoG* sig;

    NodoG(SensorBase* s) : sns(s), sig(nullptr) {}
};

class ListaGest {
private:
    NodoG* cab;

public:
    ListaGest() : cab(nullptr) {}

    ~ListaGest() {
        std::cout << "\n--- Liberacion de Memoria en Cascada ---" << std::endl;
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return NodoG* act = cab; [descripcion]
 */
        NodoG* act = cab;
        while (act != nullptr) {
            NodoG* prox = act->sig;
            
            std::cout << "[Dtor Gral] Lib Nodo: " << act->sns->obtNom() << "." << std::endl;
            delete act->sns; 
            delete act;
            act = prox;
        }
        cab = nullptr;
    }
/**
 * @brief [BREVE] insFin — descripción.
 * @param sns [descripcion]
 */

    void insFin(SensorBase* sns) {
/**
 * @brief [BREVE] NodoG — descripción.
 * @param sns [descripcion]
 */
        NodoG* nvo = new NodoG(sns);
/**
 * @brief [BREVE] if — descripción.
 * @param cab [descripcion]
 */
        if (cab == nullptr) {
            cab = nvo;
        } else {
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return NodoG* act = cab; [descripcion]
 */
            NodoG* act = cab;
            while (act->sig != nullptr) {
                act = act->sig;
            }
            act->sig = nvo;
        }
    }
/**
 * @brief [BREVE] busNom — descripción.
 * @param nom [descripcion]
 * @return SensorBase* [descripcion]
 */

    SensorBase* busNom(const char* nom) {
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return NodoG* act = cab; [descripcion]
 */
        NodoG* act = cab;
        while (act != nullptr) {
            if (strcmp(act->sns->obtNom(), nom) == 0) {
                return act->sns;
            }
            act = act->sig;
        }
        return nullptr;
    }
/**
 * @brief [BREVE] procTodo — descripción.
 */

    void procTodo() {
        std::cout << "\n--- Ejecutando Proc Polimorfico ---" << std::endl;
/**
 * @brief [BREVE] while — descripción.
 * @param nullptr [descripcion]
 * @return NodoG* act = cab; [descripcion]
 */
        NodoG* act = cab;
        while (act != nullptr) {
            std::cout << "-> Proc Sensor " << act->sns->obtNom() << "..." << std::endl;
            act->sns->procLect(); 
            act = act->sig;
        }
    }
};

#endif // LST_GST_H
